            <p1>This is the web portal for the Neuromender 3 application.</p1><br><br>
			
	       It was developed to provide an easy to use interface for viewing progress.</p1><br><br>
	
        <p1>The Neuromender system is designed to track your arm movements in a way that would encouragement a stroke survivor to use the system on a regular basis - to see if by playing the games available would help to improve the disability of the stroke survivor.</p1><br><br>
        <p1>These games fall into 2 categories:</p1><br><br>
		
        <p1>A game (Wingy) that allows for the survivor to raise and lower their elbow through a set of rings as the player flies down a mountain. The encouragement for this game being that the player is required to get the angle threshold of their elbow higher than the angle that a clinician has set for them. The motion of raising and lowering the elbow will be mirrored on the wing-suit character within the game. The flight through the rings is controlled by the movement of the elbow.</p1><br><br>
		
        <p1>A game (Targets) that allows for the survivor to extend and retract their hand towards a target presented in front of them. The aim of this game is to extend the arm beyond what has been set by the clinician. The motion of moving their affected hand around is mirrored in green within a presented green or red circle within the game.</p1><br><br>
		
        <p1>The data that will be tracked contains how frequently the application is used, what exercises are chosen, body positioning, shoulder movements, elbow movements, and hand movements - as well as changes in the elbow angle threshold and hand reach distance over time.</p1><br><br>
		
        <p1>Designed and Developed by students enrolled in Computer Science, Games Technology, and Games Software Design and Production @ Murdoch University in collaboration with Western Australian Neuroscience Research Institute (WANRI).</p1><br><br>
		
        <p1>The development originally began as Neuromend (from versions 1.0 to 2.6.1). On November 2015 the product was re-branded to Neuromender.</p1><br><br>
       
		<p1> Neuromender 3.0 was developed by:</p1><br><br>
                            <ul>
                                <li>Joshua Voysey</li>
                                <li>Connor Berry</li>
                                <li>Dave Belson</li>
                                <li>Adrian Hampel</li>
                                <li>Adam de Blanken</li>
                                <li>Gilbert Hicks</li>
                            </ul>
        <br/>
        <div>Neuromender 2.6.1 was developed by:<div>
        <br/>
        <ul>
            <li>Michael Garner</li>
        </ul>
                            
        <br/> 
		
		<div>Neuromender 2.6.0 was developed by:<div>
        <br/>
        <ul>
            <li>Alexander Arif</li>
        </ul>
                            
        <br/>      
        
        <p1> Neuromender 2.5 was developed by:</p1><br><br>
                            <ul>
                                <li>Mark Ellis</li>
                                <li>Michael Garner</li>
                                <li>Steven Impson</li>
                                <!--<li>Sam Lindsay</li>-->
                                <li>Benjamin McLeary</li>
                                <li>Michael Vatskalis</li>
                            </ul>
        <br/>
        
            
            <p1>Previous Neuromender versions were developed by:</p1><br><br>
			<ul>
                                <li>Ary Bizar</li>
				<li>James Brine</li>
				<li>Jak Gem</li>
				<li>Hazem Kalbouneh</li>
                                <li>Anopan Kandiah</li>
                                <li>Hannah Klinac</li>
                                <li>Alex Mlodawski</li>
				<li>Cameron Thompson</li>
				<li>Karl Tysoe</li>
                                <li>Bryan Yu</li>
			</ul>
                        
                        <p1>Special Thanks to:</p1><br><br> 
			<ul>
				<li>Noel Ashcroft</li>
				<li>Michelle Byrnes (client)</li>
				<li>Samantha Bay</li>
				<li>Shane Hopkins</li>
				<li>Mike Newton (client)</li>
				<li>John North</li>
				<li>Kevin Ong</li>
				<li>Shri Rai</li>
				<li>Mohd Fairuz Shiratuddin</li>
				<li>Craig Watts</li>
			</ul>
                        <br><br>
                        <p1> To find out more information you can visit the following websites: </p1><br><br>
						<a class='head' href='http://www.it.murdoch.edu.au/ives/' target="_blank">Intelligent Virtual Environment & Simulation Research Group (iVES)</a><br>
                        <a class='head' href='https://www.wanri.org/' target="_blank">WANRI</a><br>
                        <a class='head' href='https://www.it.murdoch.edu.au' target="_blank">Murdoch University</a>
						