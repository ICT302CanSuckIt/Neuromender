<?php
define('SCRIPTPATH','/neuromender3/Includes/phpChart_Professional/');
define('DEBUG', false);





/******** DO NOT MODIFY ***********/
require_once('phpChart.php');     
/**********************************/
?>