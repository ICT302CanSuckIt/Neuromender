<html>
    <head>
        <title> Neuromender | Add Role </title>
        <?php
            include "../DBConnect.php";
            include "../Calendar.php";
            require_once "../phpChart_Professional/conf.php";
            if ($_SESSION['loggedIn'] == false)
            {
                header("Location: Login.php");
                exit();
            }
        ?>       
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale-1.0">
        <link href="../../bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="../../style.css" rel="stylesheet">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
        <script src ="../../assets/js/jquery.min.js"> </script>
        <script src ="../../bootstrap/js/bootstrap.min.js"> </script>
        <script src ="../../assets/js/ie10-viewport-bug-workaround.js"> </script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
        <script type='text/javascript' src='../Main/user.js'></script>  
    </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-default" role="navigation">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle Navigation</span>
                            <span class="icon-bar"> </span>
                            <span class="icon-bar"> </span>
                            <span class="icon-bar"> </span>
                        </button>
                        <a class="navbar-brand" href="../../Dashboard.php">Neuromend </a>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <li> <a href="../../Dashboard.php"> <i class='fa fa-home fa-lg'> </i> Dashboard</a>
                            </li>
                            <?php
                                $userID = $_SESSION['UserID'];
                                $url = "location.href='../../Main/Profile.php?user=$userID&password=1'";
                                echo("<li class='active'> <a href='javascript:void(0)' onclick=$url> <i class='fa fa-user fa-lg'> </i> Profile</a></li>")
                            ?>
                            <li> <a href="../../Main/Reports.php"> <i class="fa fa-folder-open fa-lg"> </i> Reports</a></li>
                            <li> <a href="../../Main/Download.php"> <i class="fa fa-download fa-lg"> </i> Download Data</a></li>
                            <li> <a href="../../Main/About.php"> <i class='fa fa-question fa-lg'> </i> About</a></li>
			    <li> <a href="../../Main/Help.php"> <i class='fa fa-child fa-lg'> </i> Help</a></li>
			    <li> <a href="../../Main/Contact.php"> <i class='fa fa-phone fa-lg'> </i> Contact Us</a></li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right" style="display: block;">
                            <li>
                                <a href="../../Main/Logout.php" style="display: block;">
                                    <i class="fa fa-sign-out fa-lg">
                                    </i>
                                    &nbsp;Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- AREA FOR THE MAIN CONTENT -->
            <div class="jumbotron">
                <?php
                    include "AddRoleData.php"
                ?>
            </div>
            
        </div> <!-- End Container -->
        <div class="container">
            <a style="position:relative; left:28.5%;padding-right:10px;" href="https://www.murdoch.edu.au"><img src='../../Images/Murdoch.png' alt='Murdoch' height='100px' width='225px'></a>
            <a style="position:relative; left:28.5%;padding-right:10px;" href="https://www.wanri.org"><img src='../../Images/WANRI_logo.jpg' alt='WANRI' height='100px' width='225px'></a>
        </div>
    </body>
</html>

