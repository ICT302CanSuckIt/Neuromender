<?php
	if ($_SESSION['loggedIn'] == false)
	{
		header("Location: Login.php");
		exit();
	}
	error_reporting(0);
	
	
	//include ("faq.html");
	echo "<h1>User Manuals</h1>";
	if($_SESSION['SelectedRole'] <= $constSuperAdmin)
	{
		echo '<a href="../Main/Help.php?manual=Web_portal_Super_Admin">Super Admin user manual</a><br/>';
	}
	
	if($_SESSION['SelectedRole'] <= $constAdmin)
	{
		echo '<a href="../Main/Help.php?manual=Web_portal_Admin">Admin user manual</a><br/>';
	}
	
	if($_SESSION['SelectedRole'] <= $constPhysio)
	{
		echo '<a href="../Main/Help.php?manual=Web_portal_Clincian_and_Coach">Clinician user manual</a><br/>';
	}
	
	if($_SESSION['SelectedRole'] <= $constPatient)
	{
		echo '<a href="../Main/Help.php?manual=Wingman_targets_Manual">Survivor Game user manual</a><br/>';
		echo '<a href="../Main/Help.php?manual=Web_portal_Survivor">Web portal survivor user manual</a><br/>';
		
	}
	
	if (isset($_GET["manual"]))
	{
		$manual = $_GET["manual"];
		include( "../assets/" . $manual . ".html");
	}
?>