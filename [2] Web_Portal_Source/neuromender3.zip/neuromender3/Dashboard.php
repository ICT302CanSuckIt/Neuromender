<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale-1.0">
        <title> Neuromender | Dashboard </title>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="style.css" rel="stylesheet">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
        <?php
            include "Includes/DBConnect.php";
            if ($_SESSION['loggedIn'] == false)
            {
                header("Location: Main/Login.php");
                exit();
            }
	    if (isset($_SESSION['UserID']))
    	    {
            	$User = $_SESSION['UserID'];
            }
			
			date_default_timezone_set('Australia/Perth'); //set to Perth timezone, by default php sets to UTC
			include "Includes/GenerateAlerts.php";
        ?>
    </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-default" role="navigation">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle Navigation</span>
                            <span class="icon-bar"> </span>
                            <span class="icon-bar"> </span>
                            <span class="icon-bar"> </span>
                        </button>
                        <a class="navbar-brand" >Neuromender </a>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">                           
                            <li class="active"> <a href="Dashboard.php"> <i class='fa fa-home fa-lg'> </i> Dashboard</a>
                            </li>
                            <?php
                                $userID = $_SESSION['UserID'];
                                $url = "location.href='Main/Profile.php?user=$userID&password=1'";
                                echo("<li> <a href='javascript:void(0)' onclick=$url> <i class='fa fa-user fa-lg'> </i> Profile</a></li>");
                            ?>
                             <?php
                                if($_SESSION['SelectedRole'] == $constSuperAdmin || $_SESSION['SelectedRole'] == $constAdmin || $_SESSION['SelectedRole'] == $constCoach || $_SESSION['SelectedRole'] == $constPhysio)
                                {
                                    echo('<li> <a href="Main/Reports.php"> <i class="fa fa-folder-open fa-lg"> </i> Reports</a></li>');
                                }
                                if($_SESSION['SelectedRole'] == $constSuperAdmin)
                                {
                                    echo('<li> <a href="Main/Download.php"> <i class="fa fa-download fa-lg"> </i> Download Data</a></li>');
                                }
                            ?>
                            <li> <a href="Main/About.php"> <i class='fa fa-question fa-lg'> </i> About</a></li>
							<li> <a href="Main/Help.php"> <i class='fa fa-child fa-lg'> </i> Help</a></li>
							<li> <a href="Main/Contact.php"> <i class='fa fa-phone fa-lg'> </i> Contact Us</a></li>
							<li> <a href="Main/Alerts.php"> <i class="fa fa-exclamation fa-lg"> </i> Alerts</a></li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right" style="display: block;">
			    <li>
                                <?php
                                    $output = "";
                                    $selectRoles = "Select count(*) as roleCount from AssignedRoles where UserID = $User";
                                    $roleCount = getval($dbhandle, $selectRoles);
                                    if (isset($_SESSION['SelectedRole']))
                                    {
                                            $Role = $_SESSION['SelectedRole'];

                                            $roleSQL = "Select Description from Role where RoleID = $Role";
                                            $RoleDesc = getval($dbhandle, $roleSQL);
                                            $output = $output . "<a>Logged in as: $RoleDesc </a>";
                                    }
				    /*<i class='fa fa-user fa-lg'></i>
                                    if($roleCount > 1)
                                    {
                                            $sql = "Select Role.RoleID, Role.Description from AssignedRoles INNER JOIN Role on Role.RoleID = AssignedRoles.RoleID where UserID = $User";
                                            $output = $output . "<form method='post' style='display: inline;'>";
                                            $output = $output . CreateSelectBox($sql, 'roleChange', 'roleChange', 'RoleID', 'Description', '', $dbhandle);
                                            $output = $output . "<input type='submit' name='btnRoleChange' value='Change' /></form><br><br>";
                                    }
				    */
				    echo $output;
                                ?>
                            </li>

                            <li>
                                <a href="Main/Logout.php" style="display: block;">
                                    <i class="fa fa-sign-out fa-lg">
                                    </i>
                                    &nbsp;Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="jumbotron">
                <?php
                $User = $_SESSION['UserID'];
                $sql = "SELECT Users.FullName FROM Users WHERE Users.UserID = $User";
                $result = $dbhandle->query($sql);
                $user = $result->fetch_assoc();
                $FullName = $user['FullName'];
                $output;
                $output = "<h1>Welcome $FullName</h1>";
                $output = $output . "<p>Please select your destination via the panels below</p>";
                echo $output;
                ?>
            </div>
            <div class="row">
            <!-- DASHBOARD BUTTON FOR PROFILE -->
            <?php
			$hackedStyle = ""; //This is a style used if the user is super admin, so that all the tiles fit on the screen. Hackity hack.
			if($_SESSION['SelectedRole'] == $constSuperAdmin)
			{
				$hackedStyle = "style='width:20%'";
			}
			
            $userID = $_SESSION['UserID'];
            $url = "location.href='Main/Profile.php?user=$userID&password=1'";
            echo("<div class='col-lg-3 col-md-6' $hackedStyle>
                <a href='javascript:void(0)' onclick=$url>
                <div class ='panel panel-blue'>
                    <div class='panel-heading'>
                        <div class='row'>
                            <div class='col-xs-3'>
                                <i class='fa fa-user fa-5x'> </i>
                            </div>
                            <div class='col-xs-9 text-right'>
                                <div class='huge'>Profile</div>
                                <div></div>
                            </div>
                        </div>
                    </div>
                    <a href='javascript:void(0)' onclick=$url>
                        <div class='panel-footer'>
                            <span class='pull-left'> View Details</span>
                            <span class='pull-right'>
                                <i class='fa fa-arrow-circle-right'></i>
                            </span>
                            <div class='clearfix'></div>
                        </div>
                    </a>
                </div>
                </a>
            </div>");
            //DASHBOARD BUTTON FOR REPORTS
                if($_SESSION['SelectedRole'] == $constSuperAdmin || $_SESSION['SelectedRole'] == $constAdmin || $_SESSION['SelectedRole'] == $constCoach || $_SESSION['SelectedRole'] == $constPhysio)
                {
                echo("<div class='col-lg-3 col-md-6' $hackedStyle>
                        <a href='Main/Reports.php'>
                        <div class ='panel panel-green'>
                            <div class='panel-heading'>
                                <div class='row'>
                                    <div class='col-xs-3'>
                                        <i class='fa fa-folder-open fa-5x'>
                                        </i>
                                    </div>
                                    <div class='col-xs-9 text-right'>
                                        <div class='huge'>Reports</div>
                                        <div></div>
                                    </div>
                                </div>
                            </div>
                            <a href='Main/Reports.php'>
                                <div class='panel-footer'>
                                    <span class='pull-left'> View Details</span>
                                    <span class='pull-right'>
                                        <i class='fa fa-arrow-circle-right'></i>
                                    </span>
                                    <div class='clearfix'></div>
                                </div>
                            </a>
                        </div>
                        </a>
                    </div>
                    ");
                }
                
                if($_SESSION['SelectedRole'] == $constSuperAdmin)
                {
                    echo("
                    <!-- DASHBOARD BUTTON FOR CSV DATA DOWNLOAD -->
                    <div class='col-lg-3 col-md-6' $hackedStyle>
                        <a href='Main/Download.php'> 
                        <div class ='panel panel-purple'>
                            <div class='panel-heading'>
                                <div class='row'>
                                    <div class='col-xs-3'>
                                        <i class='fa fa-download fa-5x'>
                                        </i>
                                    </div>
                                    <div class='col-xs-9 text-right'>
                                        <div class='huge'>Download Data</div>
                                        <div></div>
                                    </div>
                                </div>
                            </div>
                            <a href='Main/Download.php'>
                                <div class='panel-footer'>
                                    <span class='pull-left'> View Details</span>
                                    <span class='pull-right'>
                                        <i class='fa fa-arrow-circle-right'></i>
                                    </span>
                                    <div class='clearfix'></div>
                                </div>
                            </a>
                        </div>
                        </a>
                    </div>");
                }
				
            //DASHBOARD BUTTON FOR ABOUT
            echo("<div class='col-lg-3 col-md-6' $hackedStyle>
                <a href='Main/About.php'> 
                <div class ='panel panel-yellow'>
                    <div class='panel-heading'>
                        <div class='row'>
                            <div class='col-xs-3'>
                                <i class='fa fa-question fa-5x'>
                                </i>
                            </div>
                            <div class='col-xs-9 text-right'>
                                <div class='huge'>About</div>
                                <div></div>
                            </div>
                        </div>
                    </div>
                    <a href='Main/About.php'>
                        <div class='panel-footer'>
                            <span class='pull-left'> View Details</span>
                            <span class='pull-right'>
                                <i class='fa fa-arrow-circle-right'></i>
                            </span>
                            <div class='clearfix'></div>
                        </div>
                    </a>
                </div>
                </a>
            </div>");
			
			//DASHBOARD BUTTON FOR ALERTS
            $userID = $_SESSION['UserID'];
            $url = "location.href='Main/Alerts.php?user=$userID&password=1'";
            echo("<div class='col-lg-3 col-md-6' $hackedStyle>
                <a href='javascript:void(0)' onclick=$url>
                <div class ='panel panel-red'>
                    <div class='panel-heading'>
                        <div class='row'>
                            <div class='col-xs-3'>
                                <i class='fa fa-exclamation fa-5x'> </i>
                            </div>
                            <div class='col-xs-9 text-right'>
                                <div class='huge'>Alerts</div>
                                <div></div>
                            </div>
                        </div>
                    </div>
                    <a href='javascript:void(0)' onclick=$url>
                        <div class='panel-footer'>
                            <span class='pull-left'> View Details</span>
                            <span class='pull-right'>
                                <i class='fa fa-arrow-circle-right'></i>
                            </span>
                            <div class='clearfix'></div>
                        </div>
                    </a>
                </div>
                </a>
            </div>");
			?>
			
			
            </div>
            <div class="container">
                    <a  style="position:relative; left:28.5%;padding-right:10px;padding-bottom:10px;" href="https://www.it.murdoch.edu.au"><img src='Images/Murdoch.png' alt='Murdoch' height='100px' width='225px'></a>
                    <a style="position:relative; left:28.5%;padding-right:10px;" href="https://www.wanri.org"><img src='Images/WANRI_logo.jpg' alt='WANRI' height='100px' width='225px'></a>
            </div>
        </div> <!-- End Container -->
        <script src ="assets/js/jquery.min.js"> </script>
        <script src ="bootstrap/js/bootstrap.min.js"> </script>
        <script src ="assets/js/ie10-viewport-bug-workaround.js"> </script>
    </body>
</html>
